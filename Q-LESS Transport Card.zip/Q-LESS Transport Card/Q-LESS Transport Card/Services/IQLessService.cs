﻿using Q_LESS_Transport_Card.Models.ViewModel;

namespace Q_LESS_Transport_Card.Services
{
    public interface IQLessService
    {
        PassengerViewModel GetPassengerBySVT(string ticket);
        PassengerViewModel LoadPassengerViewModel();
        TransactionViewModel LoadTransactionViewModel(string mrtLine, string svt, string selectedAction);
        bool RegisterPassenger(PassengerViewModel model);
        bool SubmitTransaction(TransactionViewModel model);
        TransactionViewModel loadDashboard();

        TransactionViewModel editTrans(string mrtlineExit, string svt);
        bool UpdateTransaction(TransactionViewModel model);
    }
}