﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Internal;
using Q_LESS_Transport_Card.Models;
using Q_LESS_Transport_Card.Models.ViewModel;
using Q_LESS_Transport_Card.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace Q_LESS_Transport_Card.Services
{
    public class QLessService : IQLessService
    {
        private readonly IQLessRepository _repo;
        public QLessService(IQLessRepository repo)
        {
            _repo = repo;
        }

        public PassengerViewModel GetPassengerBySVT(string ticket)
        {
            string discountNumber = string.Empty;
            var model = _repo.GetPassengerBySVT(ticket);
            PassengerViewModel result = new PassengerViewModel()
            {
                StoredValueTicket = model.StoredValueTicket,
                PassengerName = model.PassengerName,
                PassengerType = model.PassengerType,
                DatePurchase = model.DatePurchase,
                DiscountType = model.DiscountType,
                PWDDiscountIdNumber = model.DiscountType  =="PWD"? model.DiscountIdNumber:String.Empty,
                SeniorDiscountIdNumber = model.DiscountType == "Senior Citizen" ? model.DiscountIdNumber : String.Empty,

                Load = model.Load,
                LastUsedDate = model.LastUsedDate,
                IsRegistered = model.IsRegistered,
                Status = model.Status
            };

            return result;

        }

        public PassengerViewModel LoadPassengerViewModel()
        {
            PassengerViewModel model = new PassengerViewModel();
            List<SelectListItem> TransportCardType = new List<SelectListItem>();
            TransportCardType.Add(new SelectListItem
            {
                Text = "Regular",
                Value = "Regular"
            });
            TransportCardType.Add(new SelectListItem
            {
                Text = "Discounted",
                Value = "Discounted"
            });

            List<SelectListItem> Discountitems = new List<SelectListItem>();
            Discountitems.Add(new SelectListItem
            {
                Text = "Senior Citizen",
                Value = "Senior Citizen"
            });
            Discountitems.Add(new SelectListItem
            {
                Text = "PWD",
                Value = "PWD"
            });

            model.TransportCardTypeList = TransportCardType;
            model.DiscountTypeList = Discountitems;
            model.DatePurchase = DateTime.Now;
            model.Load = 100;
            return model;
        }

        public bool RegisterPassenger(PassengerViewModel model)
        {

            model.IsRegistered = true;
            model.Status = "Active";
            if (model.PassengerType == "Regular")
            {
                model.DiscountType = string.Empty;
                model.PWDDiscountIdNumber = string.Empty;
                model.SeniorDiscountIdNumber = string.Empty;
            }


            Passenger pass = new Passenger()
            {
                StoredValueTicket = model.StoredValueTicket,
                PassengerName = model.PassengerName,
                PassengerType = model.PassengerType,
                Load = model.Load,
                IsRegistered = model.IsRegistered,
                DatePurchase = model.DatePurchase,
                DiscountType = model.DiscountType,
                DiscountIdNumber = model.DiscountType == "PWD" ? model.PWDDiscountIdNumber: model.SeniorDiscountIdNumber,
                LastUsedDate = model.DatePurchase,
                Status = model.Status

            };

            return _repo.AddPassenger(pass);
        }


        public TransactionViewModel LoadTransactionViewModel(string mrtLine, string svt, string selectedAction)
        {
            TransactionViewModel model = new TransactionViewModel();
            Passenger passenger = new Passenger();
            passenger = _repo.GetPassengerBySVT(svt);
            if(selectedAction == "Exit")
            {
                var retrieveValue = _repo.GetTransactionBySVT(svt);
                model.MRTLineEntry = retrieveValue.MRTLineEntry;
                               
            }
            model.MRTLine = mrtLine;
            model.StoredValueTicket = svt;
            model.Action = selectedAction;
            model.TransportCardType = passenger.PassengerType;
            model.DiscountType = passenger.DiscountType;

            List < MRTLineDetail> mrtLines = new List<MRTLineDetail>();
            mrtLines = _repo.GetAllMRTLineDetails().Where(x=>x.MRTLine == mrtLine).ToList();
            //var res = mrtLines

          List<SelectListItem> EntryList = (from item in mrtLines
                                            select new SelectListItem
                                            {
                                                Text = item.MRTLineCode,
                                                Value = item.MRTLineDescription
                                            }).ToList();

            
            model.MRTLineEntryList = EntryList;
            model.FareDate = DateTime.Now;
            return model;

        }
        public TransactionViewModel editTrans(string mrtlineExit , string svt)
        {
            TransactionViewModel model = new TransactionViewModel();

            Passenger passenger = new Passenger();
            passenger = _repo.GetPassengerBySVT(svt);

            var retrieveValue = _repo.GetTransactionBySVT(svt);

            model.MRTLineEntry = retrieveValue.MRTLineEntry;
            model.MRTLine = retrieveValue.MRTLine;

            double OrigCost = _repo.GetFareMatrixByMRTLine(retrieveValue.MRTLine).Where(x => x.MRTLineEntry == retrieveValue.MRTLineEntry &&
                x.MRTLineExit == mrtlineExit).Select(s => s.Cost).FirstOrDefault();


            DateTime today = DateTime.Today;
            int transCount = _repo.GetAllFareTransactionBySVT(svt).Where(x => x.FareDate.Date == today).Count();

            double getCost = computeDiscount(passenger, OrigCost, transCount);

            model.Cost = getCost;
            model.PreviousAmount = passenger.Load;
            model.RemainingAmount = model.PreviousAmount - getCost;
            model.DiscountAmount = OrigCost - getCost;




            return model;

           
        }

       


        private  double computeDiscount(Passenger passenger, double getCost, int transCount)
        {
            if (passenger.PassengerType == "Discounted")
            {
                switch (transCount)
                {
                    case 1:
                        getCost = getCost - (int)((double)getCost * 0.30);
                        break;
                    case 2:
                        getCost = getCost - (int)((double)getCost * 0.33);
                        break;
                    case 3:
                        getCost = getCost - (int)((double)getCost * 0.33);
                        break;
                    case 4:
                        getCost = getCost - (int)((double)getCost * 0.33);
                        break;
                    default:
                        break;
                }


            }

            return getCost;
        }
       public bool UpdateTransaction(TransactionViewModel model)
        {
            Passenger passenger = new Passenger();
            passenger = _repo.GetPassengerBySVT(model.StoredValueTicket);
            passenger.Load = model.RemainingAmount;

            FareTransaction trans = new FareTransaction();
            trans = _repo.GetTransactionById(getTransId(model.StoredValueTicket));

            trans.Status = "Completed";
            trans.PreviousAmount = model.PreviousAmount;
            trans.RemainingAmount = model.RemainingAmount;
            trans.Cost = model.Cost;
            trans.DiscountAmount = model.DiscountAmount;
               
         
            bool ispassenger = _repo.EditPassenger(passenger);
            bool istrans = _repo.EditTransaction(trans);
            return ispassenger && istrans;

        }
        
        public bool SubmitTransaction(TransactionViewModel model)
        {
            if (model.Action == Actions.Entry.ToString())
                model.Status = "OnGoing";


            

            FareTransaction pass = new FareTransaction()
            {
                StoredValueTicket = model.StoredValueTicket,
                TransportCardType = model.TransportCardType,
                MRTLine = model.MRTLine,
                MRTLineEntry = model.MRTLineEntry,
                MRTLineExit = model.MRTLineExit,
                DiscountType = model.DiscountType,
                DiscountAmount = model.DiscountAmount,
                PreviousAmount = model.PreviousAmount,
                RemainingAmount = model.RemainingAmount,
                Status = "OnGoing",
                Cost = model.Cost,
                FareDate = model.FareDate

            };
                


            return _repo.AddTransaction(pass);
        }

        public TransactionViewModel loadDashboard()
        {
            TransactionViewModel model = new TransactionViewModel();
            List<SelectListItem> actions = new List<SelectListItem>();
            actions.Add(new SelectListItem
            {
                Text = "Entry",
                Value = "Entry"
            });
            actions.Add(new SelectListItem
            {
                Text = "Exit",
                Value = "Exit"
            });

            List<SelectListItem> mrtLines = new List<SelectListItem>();
            mrtLines.Add(new SelectListItem
            {
                Text = "MRTLine1",
                Value = "MRTLine1"
            });
            mrtLines.Add(new SelectListItem
            {
                Text = "MRTLine2",
                Value = "MRTLine2"
            });

            model.ActionList = actions;
            model.MrtLines = mrtLines;

            return model;
        }

        private int getTransId(string ticket)
        {
            DateTime today = DateTime.Today;
            return _repo.GetAllFareTransactionBySVT(ticket).Where(x => x.Status == "OnGoing" && x.FareDate.Date == today).Select(s => s.Id).FirstOrDefault();
        }
    }
}
