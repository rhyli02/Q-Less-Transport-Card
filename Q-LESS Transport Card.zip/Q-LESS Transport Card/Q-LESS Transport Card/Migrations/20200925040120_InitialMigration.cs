﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Q_LESS_Transport_Card.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FareTransactions",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StoredValueTicket = table.Column<string>(nullable: true),
                    TransportCardType = table.Column<string>(nullable: true),
                    MRTLine = table.Column<string>(nullable: true),
                    MRTLineEntry = table.Column<string>(nullable: true),
                    MRTLineExit = table.Column<string>(nullable: true),
                    DiscountType = table.Column<string>(nullable: true),
                    DiscountAmount = table.Column<double>(nullable: false),
                    Cost = table.Column<double>(nullable: false),
                    PreviousAmount = table.Column<double>(nullable: false),
                    RemainingAmount = table.Column<double>(nullable: false),
                    Status = table.Column<string>(nullable: true),
                    FareDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FareTransactions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MRTFareMatrices",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MRTLine = table.Column<string>(nullable: true),
                    MRTLineEntry = table.Column<string>(nullable: true),
                    MRTLineExit = table.Column<string>(nullable: true),
                    Cost = table.Column<double>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MRTFareMatrices", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MRTLineDetails",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MRTLine = table.Column<string>(nullable: true),
                    MRTLineCode = table.Column<string>(nullable: true),
                    MRTLineDescription = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MRTLineDetails", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Passengers",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StoredValueTicket = table.Column<string>(nullable: false),
                    PassengerName = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    Load = table.Column<double>(nullable: false),
                    PassengerType = table.Column<string>(nullable: true),
                    DiscountType = table.Column<string>(nullable: true),
                    DiscountIdNumber = table.Column<string>(nullable: true),
                    DatePurchase = table.Column<DateTime>(nullable: false),
                    LastUsedDate = table.Column<DateTime>(nullable: false),
                    IsRegistered = table.Column<bool>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Passengers", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FareTransactions");

            migrationBuilder.DropTable(
                name: "MRTFareMatrices");

            migrationBuilder.DropTable(
                name: "MRTLineDetails");

            migrationBuilder.DropTable(
                name: "Passengers");
        }
    }
}
