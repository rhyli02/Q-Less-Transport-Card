﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
//using System.Web.Helpers;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Q_LESS_Transport_Card.Models;
using Q_LESS_Transport_Card.Models.ViewModel;
using Q_LESS_Transport_Card.Services;


namespace Q_LESS_Transport_Card.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IQLessService _service;

        public HomeController(ILogger<HomeController> logger, IQLessService service)
        {
            _logger = logger;
            _service = service;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult FareTransaction(TransactionViewModel param)
        {
            TransactionViewModel model = new TransactionViewModel();
            model = _service.LoadTransactionViewModel(param.MRTLine, param.StoredValueTicket, param.Action);

            return View(model);
        }
        [HttpPost]
        public ActionResult GetData(string ticket = "", string line = "")
        {
            // Initialization.  
            TransactionViewModel model = new TransactionViewModel();
            model = _service.editTrans(line,ticket);


            return Json(new { prevAmt = model.PreviousAmount, cost = model.Cost, remAmt = model.RemainingAmount, disAmt= model.DiscountAmount });
        }

        //[HttpPost]
        //public IActionResult CalculateData(string param1,string param2)
        //{
            
        //    TransactionViewModel model = new TransactionViewModel();
        //    //model = _service.editTrans(b, a);


        //    return Json(new { prevAmt = model.PreviousAmount,cost= model.Cost, remAmt = model.RemainingAmount});
            
        //}
        public IActionResult CreateTransaction(TransactionViewModel param)
        {
            bool result = false;
            if (ModelState.IsValid)
            {
                if(param.MRTLineExit != String.Empty && param.MRTLineExit != null)
                   result = _service.UpdateTransaction(param);
                else
                    result = _service.SubmitTransaction(param);
            }
            if (result)
                return View("Dashboard", _service.loadDashboard());

          
            return View("FareTransaction");
        }
        public IActionResult Dashboard()
        {
            
            return View(_service.loadDashboard());
            
        }
        public IActionResult Privacy()
        {

           

            return View();
        }
        [HttpGet]
        public IActionResult Registration()
        {
            PassengerViewModel model = new PassengerViewModel();
            model = _service.LoadPassengerViewModel();

            return View(model);
        }
        [HttpPost]
        public IActionResult Registration(PassengerViewModel model)
        {
            bool result = false;
            if (ModelState.IsValid)
            {
                result = _service.RegisterPassenger(model);
            }
            if(result)
            return View("Dashboard");


            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
