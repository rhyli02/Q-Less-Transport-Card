﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Q_LESS_Transport_Card.Models
{
    public class Passenger
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string StoredValueTicket { get; set; }
        [Column(TypeName ="nvarchar(150)")]
        public string PassengerName { get; set; }
        public double Load { get; set; }
        public string PassengerType { get; set; }
        public string DiscountType { get; set; }
        public string DiscountIdNumber { get; set; }
        public DateTime DatePurchase { get; set; }
        public DateTime LastUsedDate { get; set; }
        public bool IsRegistered { get; set; }
        public string Status { get; set; }
    }
}
