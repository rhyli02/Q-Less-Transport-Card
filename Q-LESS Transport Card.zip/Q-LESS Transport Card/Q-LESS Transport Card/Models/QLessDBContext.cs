﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Q_LESS_Transport_Card.Models
{
    public class QLessDBContext : DbContext
    {
        public QLessDBContext(DbContextOptions<QLessDBContext> options):base(options)
        {

        }
        public DbSet<Passenger> Passengers { get; set; }
        public DbSet<FareTransaction> FareTransactions { get; set; }
        public DbSet<MRTFareMatrix> MRTFareMatrices { get; set; }
        public DbSet<MRTLineDetail> MRTLineDetails { get; set; }

        //private const string ConnectionString = @"server=DIEGO\SQLEXPRESS01; database=AzTeagDB; Integrated Security=true";
        //private const string ConnectionString = @"server=DIEGO\SQLEXPRESS01; database=QLessDB; Integrated Security=true";

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(ConnectionString);
        //}

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Passenger>()
        //        .Property(s => s.StoredValueTicket)
        //        .IsRequired();
        //}

    }




}

//public class Passenger
//{
//    public int Id { get; set; }
//    public string PassengerName { get; set; }
//}

