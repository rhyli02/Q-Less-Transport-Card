﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Q_LESS_Transport_Card.Models
{
    public class MRTLineDetail
    {
        public int Id { get; set; }
        public string MRTLine { get; set; }
        public string MRTLineCode { get; set; }
        public string MRTLineDescription { get; set; }
        public string Status { get; set; }

    }
}
