﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Q_LESS_Transport_Card.Models.ViewModel
{
    public class PassengerViewModel
    {
        [Required]
        public string StoredValueTicket { get; set; }
        [Required]
        public string PassengerName { get; set; }
        [Required(ErrorMessage = "Load is required")]
        [Range(100, 10000, ErrorMessage = "Load must be between 1 and 10000")]
        public double Load { get; set; }
        public string PassengerType { get; set; }
        public string DiscountType { get; set; }
       
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Senior Id Number")]
        public string SeniorDiscountIdNumber { get; set; }

        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{4})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid PWD Id Number")]
        public string PWDDiscountIdNumber { get; set; }
        [Required]
        public DateTime DatePurchase { get; set; }
        public DateTime LastUsedDate { get; set; }
        public bool IsRegistered { get; set; }
        public string Status { get; set; }

        public List<SelectListItem> TransportCardTypeList { get; set; }
       
        public List<SelectListItem> DiscountTypeList { get; set; }
    }
}
