﻿using Q_LESS_Transport_Card.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace Q_LESS_Transport_Card.Repository
{
    public class QLessRepository : IQLessRepository
    {
        private readonly QLessDBContext _context;
        public QLessRepository(QLessDBContext context)
        {
            _context = context;
        }
        #region Passenger
        public List<Passenger> GetAllPassengers()
        {
            return _context.Passengers.ToList();

        }
        public Passenger GetPassengerBySVT(string ticket)
        {
            return _context.Passengers.Where(x => x.StoredValueTicket == ticket).SingleOrDefault();
        }


        public bool AddPassenger(Passenger passenger)
        {
            bool isCreated = false;
            _context.Passengers.Add(passenger);
            var created = _context.SaveChanges();
            if (created > 0)
                isCreated = true;

            return isCreated;
        }

        public bool EditPassenger(Passenger passenger)
        {
            bool isUpdated = false;
            _context.Passengers.Update(passenger);
            var updated = _context.SaveChanges();
            if (updated > 0)
                isUpdated = true;

            return isUpdated;
        }
        #endregion
        #region FareTransaction
        public List<FareTransaction> GetAllFareTransactionBySVT(string ticket)
        {
            return _context.FareTransactions.Where(x => x.StoredValueTicket == ticket).ToList();
        }

        public FareTransaction GetTransactionBySVT(string ticket)
        {
            return _context.FareTransactions.Where(x => x.StoredValueTicket == ticket && x.Status == "OnGoing").SingleOrDefault();

        }

        public bool EditTransaction(FareTransaction fareTransaction)
        {
            bool isUpdated = false;
            _context.FareTransactions.Update(fareTransaction);
            var updated = _context.SaveChanges();
            if (updated > 0)
                isUpdated = true;

            return isUpdated;
        }
        public bool AddTransaction(FareTransaction fareTransaction)
        {
            bool isCreated = false;
            _context.FareTransactions.Add(fareTransaction);
            var created = _context.SaveChanges();
            if (created > 0)
                isCreated = true;

            return isCreated;
        }
        #endregion

        #region FareMatrix
        public List<MRTFareMatrix> GetAllFareMatrix()
        {
            return _context.MRTFareMatrices.ToList();
        }
        public List<MRTFareMatrix> GetFareMatrixByMRTLine(string line)
        {
            return _context.MRTFareMatrices.Where(x => x.MRTLine == line).ToList();
        }

        public List<MRTLineDetail> GetAllMRTLineDetails()
        {
            return _context.MRTLineDetails.ToList();
        }

        public MRTLineDetail GetMRTLineDetailBymrtLineCode(string mrtLineCode)
        {
            return _context.MRTLineDetails.Find(mrtLineCode);

        }

        public bool AddMrtLineDetail(MRTLineDetail mRTLine)
        {
            bool isCreated = false;
            _context.MRTLineDetails.Add(mRTLine);
           
            var created = _context.SaveChanges();
            if (created > 0)
                isCreated = true;

            return isCreated;
        }

        public bool AddMrtFareMatrix(MRTFareMatrix mRTFareMatrix)
        {
          
            


            bool isCreated = false;
            _context.MRTFareMatrices.Add(mRTFareMatrix);
            var created = _context.SaveChanges();
            if (created > 0)
                isCreated = true;

            return isCreated;
        }

        public FareTransaction GetTransactionById(int id)
        {
            return _context.FareTransactions.Find(id);
        }
        #endregion

    }
}
