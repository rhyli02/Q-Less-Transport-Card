﻿using Q_LESS_Transport_Card.Models;
using System.Collections.Generic;

namespace Q_LESS_Transport_Card.Repository
{
    public interface IQLessRepository
    {
        bool AddMrtFareMatrix(MRTFareMatrix mRTFareMatrix);
        bool AddMrtLineDetail(MRTLineDetail mRTLine);
        bool AddPassenger(Passenger passenger);
        bool AddTransaction(FareTransaction fareTransaction);
        bool EditPassenger(Passenger passenger);
        bool EditTransaction(FareTransaction fareTransaction);
        List<MRTFareMatrix> GetAllFareMatrix();
        List<FareTransaction> GetAllFareTransactionBySVT(string ticket);
        List<MRTLineDetail> GetAllMRTLineDetails();
        List<Passenger> GetAllPassengers();
        List<MRTFareMatrix> GetFareMatrixByMRTLine(string line);
        MRTLineDetail GetMRTLineDetailBymrtLineCode(string mrtLineCode);
        Passenger GetPassengerBySVT(string ticket);
        FareTransaction GetTransactionBySVT(string ticket);
        FareTransaction GetTransactionById(int id);
    }
}